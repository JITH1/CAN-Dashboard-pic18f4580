/*
 * File:   main.c
 * Author: JITHIN P
 *
 * Created on 11 June, 2026, 12:00 PM
 */

#include <xc.h>
#include "ecu2.h"
#define _XTAL_FREQ 20000000

unsigned char key , prev = 0x0F , last = 0x0F ;

unsigned int speed ;

unsigned int delay = 0;

void delay_1(unsigned short factor)
{
	unsigned short i, j;

	for (i = 0; i < factor; i++)
	{
		for (j = 500; j--; );
	}
}

void _init_switch()
{
    TRISC = TRISC | 0x0F ;
}

unsigned char _read_switch()
{
    return (PORTC & 0x0F) ;
}

void _init_adc()
{
    ADFM = 1;
    
    ACQT2 = 1;
    ACQT1 = 0;
    ACQT0 = 0;
    
    ADCS2 = 0;
    ADCS1 = 1;
    ADCS0 = 0;
    
    GODONE = 0;
    
    VCFG1 = 0;
    VCFG0 = 0;
    
    ADRESH = 0;
    ADRESL = 0;
    
    ADON = 1;
    
}

unsigned int _read_adc(unsigned char channel)
{
    unsigned int value;
    
    ADCON0 = (ADCON0 & 0xC3) | (channel<<2);
    
    GO = 1;
    
    while(GO);
    
    value = ((unsigned int)ADRESH<<8) | ADRESL ;
    
    return value ;
    
}

void main(void)
{
    _init_switch();
    
    _init_adc();
    
    init_can();
    
    int i = 0; 
    
    while(1)
    {
        key = _read_switch();
        
        speed = _read_adc(0x04)/10.23 ;
        
        if((key!=0x0F) && (last == 0x0F))
        {
            prev = key;
        }
        
        last = key ;
        
        delay++;
        
        if(delay>=50)
        {
            delay = 0;
            
            if(prev == 0x0E && last == 0x0E )
            {
                if(i<5)
                i++;    
                
                transmit_gear(i,0x01);
                delay_1(70);
            }
            else if(prev == 0x0D && last == 0x0D)
            {
                if(i>-1)
                i--;    
                
                transmit_gear(i,0x01);
                delay_1(70);
            }  
            
            speed_tx[0] = '0' + (speed/100)%10 ;
            speed_tx[1] = '0' + (speed/10)%10 ;
            speed_tx[2] = '0' + (speed%10);
            
            transmit_speed(i ,0x03);
            delay_1(70);
        }    
        
    }   
    
    return;
}
