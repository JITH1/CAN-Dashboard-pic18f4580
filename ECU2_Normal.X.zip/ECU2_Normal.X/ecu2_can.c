/*
 * File:   ecu2_can.c
 * Author: JITHIN P
 *
 * Created on 11 June, 2026, 12:16 PM
 */

#include <xc.h>
#include "ecu2.h"

unsigned char gear_tx[7] = {'R','N','1','2','3','4','5'};

unsigned char speed_tx[3]; 

typedef enum _CanOpMode
{
	e_can_op_mode_bits    = 0xE0,			/* Use this to access opmode bits */
	e_can_op_mode_normal  = 0x00,
	e_can_op_mode_sleep   = 0x20,
	e_can_op_mode_loop    = 0x40,
	e_can_op_mode_listen  = 0x60,
	e_can_op_mode_config  = 0x80

} CanOpMode;

/* Configure the CAN Module */
void init_can(void)
{
	/* CAN_TX = RB2, CAN_RX = RB3 */
	TRISB2 = 0;								/* CAN TX */
	TRISB3 = 1;								/* CAN RX */

	/* Enter CAN module into config mode */
							 /* clear previous mode */
	CAN_SET_OPERATION_MODE_NO_WAIT(e_can_op_mode_config);                     	/* set new mode */

	/* Wait untill desired mode is set */
	while (CANSTAT != 0x80);

	/* Enter CAN module into Mode 0 */
	ECANCON = 0x00;

	/* Initialize CAN Timing 8MHz */
	BRGCON1 = 0xE1;							/* 1110 0001, SJW=4, TQ, BRP 4 */
	BRGCON2 = 0x1B;							/* 0001 1011, SEG2PHTS 1 sampled once PS1=4TQ PropagationT 4TQ */
	BRGCON3 = 0x03;							/* 0000 0011, PS2, 4TQ */

	/*
	 * Enable Filters
	 * Filter 0
	 */
	RXFCON0 = 0x01;     

	/*
	 * Initialize Receive Filters
	 * Filter 0 = 0xFFC
	 */
	RXF0EIDH = 0x00;
	RXF0EIDL = 0x00;
	RXF0SIDH = 0x6B;
	RXF0SIDL = 0xC0;

	/* Enter CAN module into Loop back mode */
	CAN_SET_OPERATION_MODE_NO_WAIT(e_can_op_mode_normal);

	/* Set Receive Mode for buffers */
	RXB0CON = 0x00;
    
}

void transmit_gear(int gear ,unsigned char len)
{
    unsigned char g ;
    
    if(gear == -1)
    {
        g = gear_tx[0];
    }
    else if(gear == 0)
    {
        g = gear_tx[1];
    }
    else if(gear == 1)
    {
        g = gear_tx[2];
    }
    else if(gear == 2)
    {
        g = gear_tx[3];
    }
    else if(gear == 3)
    {
        g = gear_tx[4];
    }
    else if(gear == 4)
    {
        g = gear_tx[5];
    }
    else if(gear == 5)
    {
        g = gear_tx[6];
    } 
    
    while(TXB0REQ);
    
	TXB0EIDH = 0x00;		/* Extended Identifier */
	TXB0EIDL = 0x00;		/* Extended Identifier */

	/* 0x35E  0110 1011 110 */
	TXB0SIDH = 0x2C;		// ID For Gear
	TXB0SIDL = 0x00;		/* Standard Identifier */

	TXB0DLC = len;			/* Data Length Count */
	TXB0D0 = g ;			/* DataByte 0 */	
    
	TXB0REQ = 1;			/* Set the buffer to transmit */
  //  for(int i = 500 ; i-- ; );
        
}

void transmit_speed(int gear ,unsigned char len)
{
    if(gear == 0)
    {
        while(TXB0REQ);
    
      //  TXB0EIDH = 0x00;		/* Extended Identifier */
	  //  TXB0EIDL = 0x00;		/* Extended Identifier */

	    /* 0x35E  0110 1011 110 */
	    TXB0SIDH = 0xA5;		// ID for speed
	    TXB0SIDL = 0x00;		/* Standard Identifier */

	    TXB0DLC = len;			/* Data Length Count */
	    TXB0D0 = '0' ;			/* DataByte 0 */
	    TXB0D1 = '0' ;			/* DataByte 1 */
	    TXB0D2 = '0' ;			/* DataByte 2 */
	  
     	TXB0REQ = 1;			/* Set the buffer to transmit */
    //    for(int i = 500 ; i-- ; );        
    }
    else
    {
        while(TXB0REQ);
    
    //    TXB0EIDH = 0x00;		/* Extended Identifier */
	//    TXB0EIDL = 0x00;		/* Extended Identifier */

	    /* 0x35E  0110 1011 110 */
	    TXB0SIDH = 0xA5;		/* Standard Identifier */
	    TXB0SIDL = 0x00;		/* Standard Identifier */

	    TXB0DLC = len;			/* Data Length Count */
	    TXB0D0 =  speed_tx[0];			/* DataByte 0 */
	    TXB0D1 =  speed_tx[1];			/* DataByte 1 */
	    TXB0D2 =  speed_tx[2];			/* DataByte 2 */
	  
     	TXB0REQ = 1;			/* Set the buffer to transmit */
     //   for(int i = 500 ; i-- ; );        
    }    
}


