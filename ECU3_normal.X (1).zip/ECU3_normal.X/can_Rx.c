/*
  File:   can_Rx.c
  Author: JITHIN P
  Created on 9 June, 2026, 2:34 PM
 
 */

#include <xc.h>
#include "can.h"
#include "clcd.h"

/* Global Variables */
unsigned char can_payload[13];

typedef enum _CanOpMode
{
	e_can_op_mode_bits    = 0xE0,			/* Use this to access opmode bits */
	e_can_op_mode_normal  = 0x00,
	e_can_op_mode_sleep   = 0x20,
	e_can_op_mode_loop    = 0x40,
	e_can_op_mode_listen  = 0x60,
	e_can_op_mode_config  = 0x80
            
} CanOpMode;

/* Configure the CAN Module */
void init_can(void)
{
	/* CAN_TX = RB2, CAN_RX = RB3 */
	TRISB2 = 0;								/* CAN TX */
	TRISB3 = 1;								/* CAN RX */

	/* Enter CAN module into config mode */
							 /* clear previous mode */
	CAN_SET_OPERATION_MODE_NO_WAIT(e_can_op_mode_config);                     	/* set new mode */

	/* Wait untill desired mode is set */
	while (CANSTAT != 0x80);

	/* Enter CAN module into Mode 0 */
	ECANCON = 0x00;

	/* Initialize CAN Timing 8MHz */
	BRGCON1 = 0xE1;							/* 1110 0001, SJW=4, TQ, BRP 4 */
	BRGCON2 = 0x1B;							/* 0001 1011, SEG2PHTS 1 sampled once PS1=4TQ PropagationT 4TQ */
	BRGCON3 = 0x03;							/* 0000 0011, PS2, 4TQ */

	/*
	 * Enable Filters
	 * Filter 0
	 */
	RXFCON0 = 0x0F;     

	/*
	 * Initialize Receive Filters
	 * Filter 0 = 0xFFC
	 */
	RXF0EIDH = 0x00;
	RXF0EIDL = 0x00;
	RXF0SIDH = 0x18; // SID for Indicator
	RXF0SIDL = 0x00;
    
    RXF1EIDH = 0x00;
    RXF1EIDL = 0x00;
    RXF1SIDH = 0x1A; // SID for RPM 
    RXF1SIDL = 0x00;
    
    RXF2EIDH = 0x00;
	RXF2EIDL = 0x00;
	RXF2SIDH = 0xA5; // SID for Speed
	RXF2SIDL = 0x00;
    
    RXF3EIDH = 0x00;
	RXF3EIDL = 0x00;
	RXF3SIDH = 0x2C; // SID for Gear
	RXF3SIDL = 0x00;

    RXFBCON0 = 0x10;

    /*
     * Initialize Receive Masks
     * (Mode 0 - Legacy Mode: RXM0 pairs with RXF0/RXF1 -> RXB0,
     *           RXM1 pairs with RXF2/RXF3/RXF4/RXF5 -> RXB1)
     * These registers are undefined at POR, so they MUST be set
     * explicitly or the filters above will not work reliably.
     */
    RXM0EIDH = 0x00;
    RXM0EIDL = 0x00;
    RXM0SIDH = 0xFF;    /* All 11 SID bits must match exactly */
    RXM0SIDL = 0xE0;

    RXM1EIDH = 0x00;
    RXM1EIDL = 0x00;
    RXM1SIDH = 0xFF;    /* All 11 SID bits must match exactly */
    RXM1SIDL = 0xE0;

	/* Enter CAN module into Loop back mode */
	CAN_SET_OPERATION_MODE_NO_WAIT(e_can_op_mode_normal);

	/* Set Receive Mode for buffers */
	RXB0CON = 0x00;
    RXB1CON = 0x00;
    RXB0CONbits.RXM0 = 1;
    RXB0CONbits.RXM1 = 1;
    
    
}

/* Check the buffers, if it have message */
unsigned char can_receive(void)
{
	unsigned char rx_msg_flag = 0;

	if (RXB0CONbits.RXFUL) /* CheckRXB0 */
	{
		can_payload[EIDH] = RXB0EIDH;
		can_payload[EIDL] = RXB0EIDL;
		can_payload[SIDH] = RXB0SIDH;
		can_payload[SIDL] = RXB0SIDL;
		can_payload[DLC] = RXB0DLC;
		can_payload[D0] = RXB0D0;
		can_payload[D1] = RXB0D1;
		can_payload[D2] = RXB0D2;
		can_payload[D3] = RXB0D3;
		can_payload[D4] = RXB0D4;
		can_payload[D5] = RXB0D5;
		can_payload[D6] = RXB0D6;
		can_payload[D7] = RXB0D7;
        can_payload[D0 + can_payload[DLC]] = '\0';
        
        
		RXB0CONbits.RXFUL = 0;
		RXB0IF = 0;

		return 1;
	}
	else if(RXB1CONbits.RXFUL)
	{
		can_payload[EIDH] = RXB1EIDH;
		can_payload[EIDL] = RXB1EIDL;
		can_payload[SIDH] = RXB1SIDH;
		can_payload[SIDL] = RXB1SIDL;
		can_payload[DLC] = RXB1DLC;
		can_payload[D0] = RXB1D0;
		can_payload[D1] = RXB1D1;
		can_payload[D2] = RXB1D2;
		can_payload[D3] = RXB1D3;
		can_payload[D4] = RXB1D4;
		can_payload[D5] = RXB1D5;
		can_payload[D6] = RXB1D6;
		can_payload[D7] = RXB1D7;
        can_payload[D0 + can_payload[DLC]] = '\0';
        
        RXB1CONbits.RXFUL = 0 ;
        RXB1IF = 0 ;
        
        return 1;
	}
    else 
    {
        return 0;
    }    
}