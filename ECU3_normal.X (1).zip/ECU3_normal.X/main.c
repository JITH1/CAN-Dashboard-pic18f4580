/*
 * File:   main.c
 * Author: JITHIN P
 *
 * Created on 9 June, 2026, 2:29 PM
 */

#include <xc.h>
#include "clcd.h"
#include "can.h"
#define _XTAL_FREQ 20000000


#define RIGHT_LEDS   0x13   
#define LEFT_LEDS    0xE0   

volatile unsigned char blink_flag = 0;
volatile unsigned char indicator  = 0;   

void delay(unsigned short factor)
{
    unsigned short i, j;
    for (i = 0; i < factor; i++)
    {
        for (j = 500; j--; );
    }
}


void _init_led(void)
{
    TRISB &= ~(RIGHT_LEDS | LEFT_LEDS);  
    PORTB &= ~(RIGHT_LEDS | LEFT_LEDS);  
}

void init_timer0(void)
{
    T0CON = 0x87;         
    TMR0H = 0xB3;          
    TMR0L = 0xB5;
    INTCONbits.TMR0IF = 0;
    INTCONbits.TMR0IE = 1;
    INTCONbits.PEIE   = 1;
    INTCONbits.GIE    = 1;
    T0CONbits.TMR0ON  = 1;
}

void __interrupt() isr(void)
{
    if (INTCONbits.TMR0IF)
    {
        INTCONbits.TMR0IF = 0;
        TMR0H = 0xB3;       
        TMR0L = 0xB5;

        blink_flag ^= 1;    

        switch (indicator)
        {
            case 'R':
                
                if(blink_flag) 
                PORTB |= RIGHT_LEDS;
                else             
                PORTB &= ~RIGHT_LEDS;
                
                PORTB &= ~LEFT_LEDS;
                
                break;

            case 'L':
                
                if(blink_flag)
                PORTB |= LEFT_LEDS;
                else
                PORTB &= ~LEFT_LEDS;
                
                PORTB &= ~RIGHT_LEDS;
                
                break;

            case 'H':
                
                if (blink_flag)
                PORTB |= (LEFT_LEDS | RIGHT_LEDS);
                else
                PORTB &= ~(LEFT_LEDS | RIGHT_LEDS);
                
                break;

            default:
                
                PORTB &= ~(LEFT_LEDS | RIGHT_LEDS);
                break;
        }
    }
}

void main(void)
{
    init_clcd();
    init_can();
    _init_led();
    init_timer0();

    clcd_print("RPM", LINE1(0));
    clcd_print("IND", LINE1(5));
    clcd_print("SPD", LINE1(9));
    clcd_print("GR",  LINE1(13));

    while (1)
    {
        if (can_receive())
        {
            if (can_payload[SIDH] == 0x1A)
            {
                clcd_print(&can_payload[D0], LINE2(0));
            }
            else if (can_payload[SIDH] == 0x18)
            {
                clcd_print(&can_payload[D0], LINE2(6));
                indicator = can_payload[D0];   
            }
            else if (can_payload[SIDH] == 0xA5)
            {
                clcd_print(&can_payload[D0], LINE2(9));
            }
            else if (can_payload[SIDH] == 0x2C)
            {
                clcd_print(&can_payload[D0], LINE2(14));
            }
        }
    }
}