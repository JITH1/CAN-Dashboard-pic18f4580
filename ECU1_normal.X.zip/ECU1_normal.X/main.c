/*
 * File:   main.c
 * Author: JITHIN P
 *
 * Created on 8 June, 2026, 4:43 PM
 */
#include <xc.h>
#include "can_h.h"

#define _XTAL_FREQ 20000000

unsigned int rpm ;

unsigned char key , prev = 0x0F , last = 0x0F ; 

unsigned int delay  = 0; 

void delay_1(unsigned short factor)
{
	unsigned short i, j;

	for (i = 0; i < factor; i++)
	{
		for (j = 500; j--; );
	}
}

void _init_adc()
{
    ADFM = 1;
    
    ACQT2 = 1;
    ACQT1 = 0;
    ACQT0 = 0;
    
    ADCS2 = 0;
    ADCS1 = 1;
    ADCS0 = 0;
    
    GODONE = 0;
    
    VCFG1 = 0;
    VCFG0 = 0;
    
    ADRESH = 0;
    ADRESL = 0;
    
    ADON = 1;
    
}

void _init_switch()
{
    TRISC = TRISC | 0x0F ;   
}

unsigned int _read_adc(unsigned char channel)
{
    unsigned int value;
    
    ADCON0 = (ADCON0 & 0xC3) | (channel<<2);
    
    GO = 1;
    
    while(GO);
    
    value = ((unsigned int)ADRESH<<8) | ADRESL ;
    
    return value ;
    
}

char read_switch()
{
    return (PORTC & 0x0F);
}

void main(void) 
{
    _init_adc();
    _init_switch();
    init_can();
    
    while(1)
    {
        rpm = ((_read_adc(0x04)/10.23)*60);
        
        key = read_switch();
        
        if((key!=0x0F) && (last == 0x0F))
        {
            prev = key ;
            PORTB = 0x00 ;
        }
        last = key ;
        
        delay++;
        
        if(delay >= 50)
        {
            delay = 0 ;
            
            can_transmit_ind(prev ,0x02);
            delay_1(70);
            
            data[0] = '0' + (rpm/1000)%10;
            data[1] = '0' + (rpm/100)%10;
            data[2] = '0' + (rpm/10)%10;
            data[3] = '0' + rpm%10;
            
            can_transmit_rpm(0x05);
            delay_1(70);
        }      
        
    }    
    
    return;
}
